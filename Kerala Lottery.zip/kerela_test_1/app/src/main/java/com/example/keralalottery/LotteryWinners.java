package com.example.keralalottery;

public class LotteryWinners {
    private int lottery_win_num;

    public LotteryWinners(int lottery_win_num) {
        this.lottery_win_num = lottery_win_num;
    }

    public int getLottery_win_num() {
        return lottery_win_num;
    }

    public void setLottery_win_num(int lottery_win_num) {
        this.lottery_win_num = lottery_win_num;
    }
}