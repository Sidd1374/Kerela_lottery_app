package com.example.keralalottery;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

public class Activity2 extends AppCompatActivity {
    private ListView listView;
    private ArrayList<Lottery> lotteryArrayList;
    private MyCustomAdapter adapter;

    BottomNavigationView bottomNavigationView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.navigation_home);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {

            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment selectedFragment = null;
                int itemId = item.getItemId();

                if (itemId == R.id.navigation_home) {
                    selectedFragment = new navigation_home();
                } else if (itemId == R.id.navigation_cart) {
                    selectedFragment = new navigation_cart();
                } else if (itemId == R.id.navigation_notifications) {
                    selectedFragment = new navigation_notifications();
                } else if (itemId == R.id.navigation_winners) {
                    selectedFragment = new navigation_winners();
                } else if (itemId == R.id.navigation_profile) {
                    selectedFragment = new navigation_profile();
                }

                if (selectedFragment != null) {
                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.fragment_container, selectedFragment)
                            .commit();
                }

                return true;
            }
        });

    }
}